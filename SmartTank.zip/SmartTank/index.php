<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Smart Liquid Monitoring System</title>
	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
	<link rel="stylesheet" href="assets/css/ready.css">
	<link rel="stylesheet" href="assets/css/demo.css">
	<style>
        .liquidFillGaugeText { font-family: Helvetica; font-weight: bold; }
    </style>
    <script src="https://d3js.org/d3.v3.min.js" language="JavaScript"></script>
    <script src="liquidFillGauge.js" language="JavaScript"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
	<div class="wrapper">
		<div class="main-header">
			<div class="logo-header">
				<a href="index.html" class="logo">
					SMART TANK
				</a>
				<button class="navbar-toggler sidenav-toggler ml-auto" type="button" data-toggle="collapse" data-target="collapse" aria-controls="sidebar" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<button class="topbar-toggler more"><i class="la la-ellipsis-v"></i></button>
			</div>
			<nav class="navbar navbar-header navbar-expand-lg">
				<div class="container-fluid">
					
					<form class="navbar-left navbar-form nav-search mr-md-3" action="">
						<div class="input-group">
							<input type="text" placeholder="Search ..." class="form-control">
							<div class="input-group-append">
								<span class="input-group-text">
									<i class="la la-search search-icon"></i>
								</span>
							</div>
						</div>
					</form>
					</div>
				</nav>
			</div>
			<div class="sidebar">
				<div class="scrollbar-inner sidebar-wrapper">
					<div class="user">
						<div class="photo">
							<img src="assets/img/progile.png">
						</div>
						<div class="info">
							<a class="" data-toggle="collapse" href="#collapseExample" aria-expanded="true">
								<span>
									User
									<span class="user-level">User</span>
									<span class="caret"></span>
								</span>
							</a>
							<div class="clearfix"></div>

							<div class="collapse in" id="collapseExample" aria-expanded="true" style="">
								<ul class="nav">
									<li>
										<a href="#profile">
											<span class="link-collapse">My Profile</span>
										</a>
									</li>
									<li>
										
											<a href = "logout.php">
											<span class="link-collapse">Sign Out</span>
										</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
					<ul class="nav">
						<li class="nav-item active">
							<a href="index.php">
								<i class="la la-dashboard"></i>
								<p>Dashboard</p>
								
							</a>
						</li>

					
					</ul>

				</div>
			</div>
			<div class="main-panel">
				<div class="content">
					<div class="container-fluid">
						<h3 class="page-title">Dashboard</h3>
						<div class="row">
							<div class="col-md-6">
								<div class="card card-stats card-warning">
									<div class="card-body ">
										<div class="row">
											<div class="col-5">
												<div class="icon-big text-center">
													<!-- <i class="la la-money-bill-wave"></i> -->
													<i class="fas fa-hand-holding-usd"></i>
												</div>
											</div>
											<div class="col-7 d-flex align-items-center">
												<div class="numbers">
													<p class="card-category">Cash</p>
													<h7 class="card-title" id="cash">0</h7><span>RWF</span>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							
							
							<div class="col-md-6">
								<div class="card card-stats card-primary">
									<div class="card-body ">
										<div class="row">
											<div class="col-5">
												<div class="icon-big text-center">
													<!-- <i class="la la-fill-drip"></i> -->
													<i class="fas fa-fill-drip"></i>
												</div>
											</div>
											<div class="col-7 d-flex align-items-center">
												<div class="numbers">
													<p class="card-category">Millilitres</p>
													<h8 class="card-title" id="li">0</h8><span style="font-size: 20px;">ml</span>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>

						</div>
						
						<!-- <div class="row"> -->
							<!-- <div class="col-md-6"> -->
								<div class="card">
									<div class="card-header">
										<h2 class="card-title">Tank Level</h2>
										
									</div>
									<div class="card-body">
										<svg id="fillgauge4" width="100%" height="320" ></svg>
									</div>
								</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<script language="JavaScript">
   var obj;
   var a;

    var config3 = liquidFillGaugeDefaultSettings();
    config3.textVertPosition = 0.8;
    config3.waveAnimateTime = 1000;
    config3.waveHeight = 0.15;
    config3.waveAnimate = true;
    config3.waveOffset = 0.25;
    config3.valueCountUp = false;
    config3.displayPercent = true;
    //config3.circleThickness = 0.1;
    config3.textVertPosition = 0.50;
    config3.waveCount = 1;
    var gauge4 = loadLiquidFillGauge("fillgauge4", 0, config3);
    
    setInterval(function(){

    $.ajax({
   url : 'http://localhost/SmartTank/getdistance.php', // your php file
   type : 'GET', // type of the HTTP request
   success : function(data){
      obj = jQuery.parseJSON(data);
      a=obj.level;
      //console.log(a);
      gauge4.update(a);
    
  }
});
}, 2000);

setInterval(function(){

    $.ajax({
   url : 'http://localhost/SmartTank/water.php', // your php file
   type : 'GET', // type of the HTTP request
   success : function(data){
      obj1 = jQuery.parseJSON(data);
      document.getElementById("cash").innerHTML= obj1.coin_frw;
      document.getElementById("li").innerHTML= obj1.coin_litre;
  }
});
}, 2000);
</script>
</script>

</body>
<script src="assets/js/core/jquery.3.2.1.min.js"></script>
<script src="assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
<script src="assets/js/core/popper.min.js"></script>
<script src="assets/js/core/bootstrap.min.js"></script>
<script src="assets/js/plugin/chartist/chartist.min.js"></script>
<script src="assets/js/plugin/chartist/plugin/chartist-plugin-tooltip.min.js"></script>
<!-- <script src="assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script> -->
<script src="assets/js/plugin/bootstrap-toggle/bootstrap-toggle.min.js"></script>
<script src="assets/js/plugin/jquery-mapael/jquery.mapael.min.js"></script>
<script src="assets/js/plugin/jquery-mapael/maps/world_countries.min.js"></script>
<script src="assets/js/plugin/chart-circle/circles.min.js"></script>
<script src="assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>
<script src="assets/js/ready.min.js"></script>
<script src="assets/js/demo.js"></script>
</html>