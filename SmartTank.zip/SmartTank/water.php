<?php 
    $serverName = "localhost";
    $userName = "root";
    $password = "";
    $dbName = "liquid_db";

    //creat connection
    $conn = new mysqli($serverName,$userName, $password, $dbName);

    $query = "Select * FROM cash ORDER BY id DESC LIMIT 1";
    $res = mysqli_query($conn, $query);
    $data = mysqli_fetch_array($res);
    $json_string = json_encode($data, JSON_PRETTY_PRINT);
   //  $i_status = $data['status_1'];
    echo $json_string;

