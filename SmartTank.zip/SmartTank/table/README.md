# bootstrap-pagination-php-mysql
Bootstrap Pagination in PHP and MySQL
Follow this tutorial @ https://www.youtube.com/watch?v=S0Getpg3l_A
