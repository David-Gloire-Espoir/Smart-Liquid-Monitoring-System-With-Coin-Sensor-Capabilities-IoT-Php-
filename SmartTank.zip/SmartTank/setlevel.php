<?php

if(isset($_GET["level"])) {
   $level = $_GET["level"]; // get temperature value from HTTP GET

   $servername = "localhost";
   $username = "root";
   $password = "";
   $dbname = "coin";

   // Create connection
   $conn = new mysqli($servername, $username, $password, $dbname);
   // Check connection
   if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
   }



   /*$sql = "UPDATE  tbl_hum_temp SET Humidity='$humidity', Temperature='$temperature' WHERE ID=1";*/
$sql = "UPDATE water_level SET level='$level' WHERE id=1";



   if ($conn->query($sql) === TRUE) {
      echo "Water Level updated successfully";
   } else {
      echo "Error: " . $sql . " => " . $conn->error;
   }

   $conn->close();
} else {
   echo "Water level is not set";
}
?>