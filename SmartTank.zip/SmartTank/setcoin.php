<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "liquid_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
}

if(isset($_GET["litre"]) && isset($_GET["frw"]) && isset($_GET["status"]) && isset($_GET["level"])) {
   $litre = $_GET["litre"]; // get temperature value from HTTP GET
   $frw = $_GET["frw"]; // get temperature value from HTTP GET
   $level = $_GET['level'];
   $status = $_GET['status'];
   
$sql = "UPDATE cash SET coin_frw='$frw', coin_litre='$litre', status_1='$status' WHERE id=1";

   if ($conn->query($sql) === TRUE) {
         $query = "INSERT INTO `water_levels` (`level`) VALUES ('$level');";
         if ($conn->query($query) !== TRUE) {
            echo "Error: " . $query . "<br>" . $conn->error;
         } else {
            echo "saved";
         }
   } else {
      echo "Error: " . $sql . " => " . $conn->error;
   }

   $conn->close();
} else {
   echo "pump is not set";
}