<?php
 $servername = "localhost";
 $username = "root";
 $password = "";
 $dbname = "liquid_db";

if(isset($_GET["status"])) {
   $status = $_GET["status"]; // get temperature value from HTTP GET

   // Create connection
   $conn = new mysqli($servername, $username, $password, $dbname);
   // Check connection
   if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
   }

    $sql = "UPDATE cash SET status_1='$status' WHERE id=1";

    if ($conn->query($sql) === TRUE) {
            echo "get";
    } else {
        echo "Error: " . $sql . " => " . $conn->error;
    }

   $conn->close();
} else {
   echo "pump is not set";
}